using System;
namespace fronotallyapi.Models
{
  public class masterStage
  {
    public int fronocompanyId { get; set; }
    public string TallyMasterType { get; set; }
    public string TallyMasterName { get; set; }

    public long Id { get; set; }
    public string Name { get; set; }
    public long ParentId { get; set; }

    public string Address1 { get; set; }
    public string Address2 { get; set; }
    public string Address3 { get; set; }
    public string Address4 { get; set; }

    public bool IsTDS { get; set; }
    public int SATDSId { get; set; }
    public bool IsTCS { get; set; }
    public int SATCSCategoryId { get; set; }
    public bool IsGST { get; set; }
    public long TaxTypeId { get; set; }
    public long HSNCodeId { get; set; }
    public bool IsCostCentre { get; set; }
    public decimal OpeningBalance { get; set; }
    public string DrCr { get; set; }


  }
}
