using System;
namespace fronotallyapi.Models
{
  public class mappingData
  {
  }
}
